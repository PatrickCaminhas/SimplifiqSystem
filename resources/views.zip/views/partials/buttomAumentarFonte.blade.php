    <button class="btn btn-secondary py-2 mt-2" id="font-size-btn" type="button" aria-label="Increase font size">
        <i id="font-size-icon" class="bi bi-zoom-in"></i>

    </button>

