<button id="toggle-theme" class="btn btn-secondary py-2 mt-2">
    <span id="theme-icon" class="bi bi-moon-stars-fill"></span>
</button>
