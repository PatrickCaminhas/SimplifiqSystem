<x-mail::message>
# Introdução

O corpo da mensagem

<x-mail::button :url="''">
Texto do botão
</x-mail::button>
Obrigado,<br>
{{ config('app.name') }}
</x-mail::message>
