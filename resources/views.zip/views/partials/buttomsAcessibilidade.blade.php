<div class="dropdown position-fixed bottom-0 end-0 mb-3 me-3 bd-mode-toggle">

@include('partials.buttomAumentarFonte')
<br>
@include('partials.buttomLightAndDark')
</div>
